# @babel/helper-validator-identifier

> Validate identifier/keywords name

See our website [@babel/helper-validator-identifier](https://babeljs.io/docs/en/next/babel-helper-validator-identifier.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-validator-identifier
```

or using yarn:

```sh
yarn add @babel/helper-validator-identifier --dev
```
