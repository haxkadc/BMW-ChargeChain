export * from 'rxjs-compat/util/Immediate';
