export * from 'rxjs-compat/util/isObject';
