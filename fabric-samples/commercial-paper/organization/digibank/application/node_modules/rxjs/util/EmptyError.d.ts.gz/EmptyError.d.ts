export * from 'rxjs-compat/util/EmptyError';
