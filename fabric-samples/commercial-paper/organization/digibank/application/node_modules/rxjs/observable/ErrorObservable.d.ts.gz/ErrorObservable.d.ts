export * from 'rxjs-compat/observable/ErrorObservable';
