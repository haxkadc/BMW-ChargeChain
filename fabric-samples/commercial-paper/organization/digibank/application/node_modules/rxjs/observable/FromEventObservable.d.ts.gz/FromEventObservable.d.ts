export * from 'rxjs-compat/observable/FromEventObservable';
