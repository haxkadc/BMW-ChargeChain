export * from 'rxjs-compat/observable/PairsObservable';
