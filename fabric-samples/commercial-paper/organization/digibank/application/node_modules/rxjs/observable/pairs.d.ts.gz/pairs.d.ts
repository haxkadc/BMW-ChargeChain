export * from 'rxjs-compat/observable/pairs';
