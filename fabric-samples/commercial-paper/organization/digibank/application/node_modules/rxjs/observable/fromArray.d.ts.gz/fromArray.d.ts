export * from 'rxjs-compat/observable/fromArray';
