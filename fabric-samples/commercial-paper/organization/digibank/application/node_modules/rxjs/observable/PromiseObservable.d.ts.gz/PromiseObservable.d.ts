export * from 'rxjs-compat/observable/PromiseObservable';
