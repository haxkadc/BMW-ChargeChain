export * from 'rxjs-compat/observable/FromObservable';
