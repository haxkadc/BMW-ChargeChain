export * from 'rxjs-compat/observable/ScalarObservable';
