/** @deprecated do not use, this is no longer checked by RxJS internals */
export declare const rxSubscriber: string | symbol;
/**
 * @deprecated use rxSubscriber instead
 */
export declare const $$rxSubscriber: string | symbol;
