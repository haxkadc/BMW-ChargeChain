/** Identifies an input as being an Iterable */
export declare function isIterable(input: any): input is Iterable<any>;
