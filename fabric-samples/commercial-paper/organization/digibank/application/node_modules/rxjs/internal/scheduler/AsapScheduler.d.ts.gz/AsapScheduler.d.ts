import { AsyncAction } from './AsyncAction';
import { AsyncScheduler } from './AsyncScheduler';
export declare class AsapScheduler extends AsyncScheduler {
    flush(action?: AsyncAction<any>): void;
}
