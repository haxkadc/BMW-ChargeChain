declare const _root: any;
export { _root as root };
