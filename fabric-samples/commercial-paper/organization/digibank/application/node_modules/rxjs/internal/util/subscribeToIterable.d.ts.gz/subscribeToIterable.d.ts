import { Subscriber } from '../Subscriber';
export declare const subscribeToIterable: <T>(iterable: Iterable<T>) => (subscriber: Subscriber<T>) => Subscriber<T>;
