export declare function isDate(value: any): value is Date;
