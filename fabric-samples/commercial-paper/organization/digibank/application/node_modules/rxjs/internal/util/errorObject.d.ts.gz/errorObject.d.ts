export declare const errorObject: any;
