export declare function tryCatch<T extends Function>(fn: T): T;
