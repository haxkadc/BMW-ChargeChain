import 'rxjs-compat/add/operator/switch';
