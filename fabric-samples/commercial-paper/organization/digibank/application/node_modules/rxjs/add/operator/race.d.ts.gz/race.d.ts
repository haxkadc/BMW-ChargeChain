import 'rxjs-compat/add/operator/race';
