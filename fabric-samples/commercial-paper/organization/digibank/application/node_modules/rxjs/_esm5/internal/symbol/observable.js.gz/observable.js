/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export var observable = /*@__PURE__*/ (function () { return typeof Symbol === 'function' && Symbol.observable || '@@observable'; })();
//# sourceMappingURL=observable.js.map
