/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export var rxSubscriber = /*@__PURE__*/ (function () {
    return typeof Symbol === 'function'
        ? /*@__PURE__*/ Symbol('rxSubscriber')
        : '@@rxSubscriber_' + /*@__PURE__*/ Math.random();
})();
export var $$rxSubscriber = rxSubscriber;
//# sourceMappingURL=rxSubscriber.js.map
