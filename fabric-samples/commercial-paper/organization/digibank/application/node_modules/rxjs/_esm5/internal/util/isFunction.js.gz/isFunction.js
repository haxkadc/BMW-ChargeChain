/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function isFunction(x) {
    return typeof x === 'function';
}
//# sourceMappingURL=isFunction.js.map
