/** PURE_IMPORTS_START _AsyncAction,_AsyncScheduler PURE_IMPORTS_END */
import { AsyncAction } from './AsyncAction';
import { AsyncScheduler } from './AsyncScheduler';
export var asyncScheduler = /*@__PURE__*/ new AsyncScheduler(AsyncAction);
export var async = asyncScheduler;
//# sourceMappingURL=async.js.map
