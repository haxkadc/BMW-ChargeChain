/** PURE_IMPORTS_START _AjaxObservable PURE_IMPORTS_END */
import { AjaxObservable } from './AjaxObservable';
export var ajax = /*@__PURE__*/ (function () { return AjaxObservable.create; })();
//# sourceMappingURL=ajax.js.map
