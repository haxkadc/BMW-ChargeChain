/** PURE_IMPORTS_START _AsapAction,_AsapScheduler PURE_IMPORTS_END */
import { AsapAction } from './AsapAction';
import { AsapScheduler } from './AsapScheduler';
export var asapScheduler = /*@__PURE__*/ new AsapScheduler(AsapAction);
export var asap = asapScheduler;
//# sourceMappingURL=asap.js.map
