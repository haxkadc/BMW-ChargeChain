export * from 'rxjs-compat/operators/bufferWhen';
