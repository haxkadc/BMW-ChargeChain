export * from 'rxjs-compat/operators/sample';
