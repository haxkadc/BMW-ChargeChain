export * from 'rxjs-compat/util/isArray';
