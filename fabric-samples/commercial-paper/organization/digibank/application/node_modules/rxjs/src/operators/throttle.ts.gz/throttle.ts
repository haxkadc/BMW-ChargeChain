export * from 'rxjs-compat/operators/throttle';
