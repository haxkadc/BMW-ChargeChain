export * from 'rxjs-compat/operators/throttleTime';
