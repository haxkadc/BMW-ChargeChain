export * from 'rxjs-compat/util/isScheduler';
