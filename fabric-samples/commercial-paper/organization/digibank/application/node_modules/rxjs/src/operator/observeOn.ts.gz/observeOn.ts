export * from 'rxjs-compat/operator/observeOn';
