export * from 'rxjs-compat/operators/timestamp';
