export * from 'rxjs-compat/operators/window';
