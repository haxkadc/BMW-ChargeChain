export * from 'rxjs-compat/operator/merge';
