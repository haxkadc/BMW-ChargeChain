export * from 'rxjs-compat/observable/IfObservable';
