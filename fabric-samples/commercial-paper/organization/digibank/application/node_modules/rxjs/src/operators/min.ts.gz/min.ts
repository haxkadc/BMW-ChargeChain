export * from 'rxjs-compat/operators/min';
