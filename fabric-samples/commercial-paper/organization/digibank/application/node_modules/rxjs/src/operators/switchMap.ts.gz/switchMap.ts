export * from 'rxjs-compat/operators/switchMap';
