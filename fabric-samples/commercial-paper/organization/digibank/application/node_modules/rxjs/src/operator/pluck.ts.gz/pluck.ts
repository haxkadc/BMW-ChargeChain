export * from 'rxjs-compat/operator/pluck';
