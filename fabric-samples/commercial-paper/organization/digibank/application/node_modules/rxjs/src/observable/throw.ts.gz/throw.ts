export * from 'rxjs-compat/observable/throw';
