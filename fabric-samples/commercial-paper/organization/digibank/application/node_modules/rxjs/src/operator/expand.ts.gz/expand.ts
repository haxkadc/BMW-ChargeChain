export * from 'rxjs-compat/operator/expand';
