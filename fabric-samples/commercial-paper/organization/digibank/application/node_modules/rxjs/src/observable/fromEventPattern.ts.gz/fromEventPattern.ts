export * from 'rxjs-compat/observable/fromEventPattern';
