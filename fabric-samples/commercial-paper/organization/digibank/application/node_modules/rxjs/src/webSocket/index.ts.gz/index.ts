export { webSocket as webSocket } from '../internal/observable/dom/webSocket';
export { WebSocketSubject, WebSocketSubjectConfig } from '../internal/observable/dom/WebSocketSubject';
