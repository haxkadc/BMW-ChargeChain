export * from 'rxjs-compat/operator/throttleTime';
