export * from 'rxjs-compat/operators/withLatestFrom';
