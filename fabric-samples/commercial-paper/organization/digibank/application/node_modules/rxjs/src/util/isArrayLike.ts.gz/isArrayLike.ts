export * from 'rxjs-compat/util/isArrayLike';
