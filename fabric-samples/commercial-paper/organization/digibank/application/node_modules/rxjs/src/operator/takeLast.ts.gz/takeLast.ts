export * from 'rxjs-compat/operator/takeLast';
