export * from 'rxjs-compat/operators/takeLast';
