export * from 'rxjs-compat/operators/mergeMapTo';
