export * from 'rxjs-compat/operators/max';
