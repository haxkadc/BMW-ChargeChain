export * from 'rxjs-compat/operators/skipWhile';
