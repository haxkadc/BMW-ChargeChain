export * from 'rxjs-compat/util/identity';
