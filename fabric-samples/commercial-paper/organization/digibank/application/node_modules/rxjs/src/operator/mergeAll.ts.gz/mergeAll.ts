export * from 'rxjs-compat/operator/mergeAll';
