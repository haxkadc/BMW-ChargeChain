export * from 'rxjs-compat/operators/switchAll';
