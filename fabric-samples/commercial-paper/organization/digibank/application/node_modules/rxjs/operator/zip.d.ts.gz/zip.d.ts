export * from 'rxjs-compat/operator/zip';
