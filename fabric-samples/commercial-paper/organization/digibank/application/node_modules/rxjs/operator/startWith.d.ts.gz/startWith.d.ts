export * from 'rxjs-compat/operator/startWith';
