export * from 'rxjs-compat/operator/timestamp';
