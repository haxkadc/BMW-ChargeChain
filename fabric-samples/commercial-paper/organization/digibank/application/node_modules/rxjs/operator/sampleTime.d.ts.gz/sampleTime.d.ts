export * from 'rxjs-compat/operator/sampleTime';
