export * from 'rxjs-compat/operator/finally';
