export * from 'rxjs-compat/operator/toArray';
