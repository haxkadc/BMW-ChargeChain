export * from 'rxjs-compat/operator/mapTo';
