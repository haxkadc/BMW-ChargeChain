export * from 'rxjs-compat/operator/filter';
