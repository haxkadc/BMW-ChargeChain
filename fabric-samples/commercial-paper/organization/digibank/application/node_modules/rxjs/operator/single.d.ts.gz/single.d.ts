export * from 'rxjs-compat/operator/single';
