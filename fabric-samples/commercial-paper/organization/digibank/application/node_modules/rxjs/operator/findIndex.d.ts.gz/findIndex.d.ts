export * from 'rxjs-compat/operator/findIndex';
