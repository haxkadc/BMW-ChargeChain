export * from 'rxjs-compat/operators/throwIfEmpty';
