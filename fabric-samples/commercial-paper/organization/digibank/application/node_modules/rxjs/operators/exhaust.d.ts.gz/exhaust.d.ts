export * from 'rxjs-compat/operators/exhaust';
