export * from 'rxjs-compat/operators/mergeScan';
