export * from 'rxjs-compat/operators/take';
