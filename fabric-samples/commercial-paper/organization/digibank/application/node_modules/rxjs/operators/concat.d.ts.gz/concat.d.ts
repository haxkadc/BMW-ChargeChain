export * from 'rxjs-compat/operators/concat';
