export * from 'rxjs-compat/operators/skipLast';
