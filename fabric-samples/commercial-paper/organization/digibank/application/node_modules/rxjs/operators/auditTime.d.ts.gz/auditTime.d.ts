export * from 'rxjs-compat/operators/auditTime';
