export * from 'rxjs-compat/operators/windowTime';
