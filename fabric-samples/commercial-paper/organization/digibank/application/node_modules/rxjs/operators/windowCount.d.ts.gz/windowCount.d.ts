export * from 'rxjs-compat/operators/windowCount';
