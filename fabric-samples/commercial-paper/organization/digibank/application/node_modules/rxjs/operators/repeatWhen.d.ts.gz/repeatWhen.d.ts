export * from 'rxjs-compat/operators/repeatWhen';
