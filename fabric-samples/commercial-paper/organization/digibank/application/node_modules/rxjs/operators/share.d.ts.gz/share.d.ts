export * from 'rxjs-compat/operators/share';
