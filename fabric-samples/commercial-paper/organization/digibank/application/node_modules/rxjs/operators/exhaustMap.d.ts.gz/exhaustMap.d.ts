export * from 'rxjs-compat/operators/exhaustMap';
