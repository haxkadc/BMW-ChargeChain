export * from 'rxjs-compat/operators/windowToggle';
