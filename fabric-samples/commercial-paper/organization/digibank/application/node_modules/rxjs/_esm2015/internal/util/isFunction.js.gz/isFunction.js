export function isFunction(x) {
    return typeof x === 'function';
}
//# sourceMappingURL=isFunction.js.map