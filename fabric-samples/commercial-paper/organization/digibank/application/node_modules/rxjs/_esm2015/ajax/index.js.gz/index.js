export { ajax } from '../internal/observable/dom/ajax';
export { AjaxResponse, AjaxError, AjaxTimeoutError } from '../internal/observable/dom/AjaxObservable';
//# sourceMappingURL=index.js.map