export function noop() { }
//# sourceMappingURL=noop.js.map