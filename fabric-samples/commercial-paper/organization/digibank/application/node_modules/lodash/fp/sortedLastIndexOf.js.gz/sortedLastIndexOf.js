var convert = require('./convert'),
    func = convert('sortedLastIndexOf', require('../sortedLastIndexOf'));

func.placeholder = require('./placeholder');
module.exports = func;
