var convert = require('./convert'),
    func = convert('uniqWith', require('../uniqWith'));

func.placeholder = require('./placeholder');
module.exports = func;
