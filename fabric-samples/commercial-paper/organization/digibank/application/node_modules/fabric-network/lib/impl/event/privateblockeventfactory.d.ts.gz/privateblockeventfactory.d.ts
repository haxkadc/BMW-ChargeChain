import { EventInfo } from 'fabric-common';
import { BlockEvent } from '../../events';
export declare function newPrivateBlockEvent(eventInfo: EventInfo): BlockEvent;
