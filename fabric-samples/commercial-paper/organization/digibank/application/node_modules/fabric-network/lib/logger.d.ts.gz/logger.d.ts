import { Utils } from 'fabric-common';
export declare const getLogger: typeof Utils.getLogger;
