export declare const VALID_STATUS = "VALID";
export declare function getStatusForCode(code: number): string;
