import { EventInfo } from 'fabric-common';
import { BlockEvent } from '../../events';
export declare function newFilteredBlockEvent(eventInfo: EventInfo): BlockEvent;
