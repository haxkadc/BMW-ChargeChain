/// <reference types="node" />
import { BlockType, Endorser } from 'fabric-common';
import * as fabproto6 from 'fabric-protos';
import { Checkpointer } from './checkpointer';
import Long = require('long');
export declare type EventType = BlockType;
export interface BlockEvent {
    readonly blockNumber: Long;
    readonly blockData: fabproto6.protos.IFilteredBlock | fabproto6.common.IBlock;
    getTransactionEvents(): TransactionEvent[];
}
export interface TransactionEvent {
    readonly transactionId: string;
    readonly status: string;
    readonly isValid: boolean;
    readonly transactionData: fabproto6.protos.ITransaction | fabproto6.protos.IFilteredTransaction;
    readonly privateData?: any;
    getBlockEvent(): BlockEvent;
    getContractEvents(): ContractEvent[];
}
export interface ContractEvent {
    readonly chaincodeId: string;
    readonly eventName: string;
    readonly payload?: Buffer;
    getTransactionEvent(): TransactionEvent;
}
export declare type BlockListener = (event: BlockEvent) => Promise<void>;
export declare type ContractListener = (event: ContractEvent) => Promise<void>;
export interface ListenerOptions {
    startBlock?: number | string | Long;
    type?: EventType;
    checkpointer?: Checkpointer;
}
export interface CommitError extends Error {
    peer: Endorser;
}
export interface CommitEvent extends TransactionEvent {
    readonly peer: Endorser;
}
export declare type CommitListener = (error?: CommitError, event?: CommitEvent) => void;
