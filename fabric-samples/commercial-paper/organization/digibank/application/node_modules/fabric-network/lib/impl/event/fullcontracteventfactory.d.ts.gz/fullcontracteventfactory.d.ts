import { ContractEvent, TransactionEvent } from '../../events';
export declare function newFullContractEvents(transactionEvent: TransactionEvent): ContractEvent[];
