/// <reference types="node" />
export declare const CIPHER_SUITES: string | undefined;
export declare function getDefaultRootsData(): Buffer | null;
