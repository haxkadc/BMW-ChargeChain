
var navigator = {};
navigator.userAgent = false;

var window = {};
