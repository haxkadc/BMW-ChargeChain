# gojsonreference
An implementation of JSON Reference - Go language

## Dependencies
https://github.com/xeipuuv/gojsonpointer

## References
http://tools.ietf.org/html/draft-ietf-appsawg-json-pointer-07

http://tools.ietf.org/html/draft-pbryan-zyp-json-ref-03
