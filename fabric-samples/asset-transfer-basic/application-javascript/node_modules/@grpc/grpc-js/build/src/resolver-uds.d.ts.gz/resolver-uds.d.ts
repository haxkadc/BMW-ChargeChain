export declare function setup(): void;
