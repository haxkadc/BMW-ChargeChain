// generated with: printf 'a123456%.0s' {1..99999} | sha1sum
sjcl.test.vector.sha1long = 
[
[Array(100000).join('a123456'), "fd8513d5ba504eacf786091af50b75dcfe25b145"]
];
