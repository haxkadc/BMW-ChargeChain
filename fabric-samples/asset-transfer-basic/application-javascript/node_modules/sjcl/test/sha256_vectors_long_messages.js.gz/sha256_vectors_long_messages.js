// generated with: printf 'a123456%.0s' {1..99999} | sha256sum
sjcl.test.vector.sha256long = 
[
[Array(100000).join('a123456'), "397df3bf09b046b41b65edebd20e440308188e441c7e57e400cad21b86333d77"]
];
