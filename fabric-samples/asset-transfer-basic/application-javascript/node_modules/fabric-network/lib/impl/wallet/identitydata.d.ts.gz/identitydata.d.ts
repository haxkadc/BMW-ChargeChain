export interface IdentityData {
    readonly type: string;
    readonly version: number;
}
