export interface Identity {
    type: string;
    mspId: string;
}
