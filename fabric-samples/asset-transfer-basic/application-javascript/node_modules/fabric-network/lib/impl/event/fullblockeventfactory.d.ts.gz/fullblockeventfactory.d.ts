import { EventInfo } from 'fabric-common';
import { BlockEvent } from '../../events';
export declare function newFullBlockEvent(eventInfo: EventInfo): BlockEvent;
